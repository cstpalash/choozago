Reset Parameters in a Parameter Group
-------------------------------------

This example shows how to reset all of the parameters in a parameter group.

Command::

   aws redshift reset-cluster-parameter-group --parameter-group-name myclusterparametergroup --reset-all-parameters

